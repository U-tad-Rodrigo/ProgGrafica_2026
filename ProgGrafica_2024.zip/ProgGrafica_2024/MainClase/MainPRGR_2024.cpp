//ESTA MACRO SÓLO APARECE UNA VEZ EN EL ARCHIVO QUE CONTENGA EL MAIN()
#define GLAD_BIN
#include "common.h"
#include "Object3D.h"
#include <iostream>
#include "EventManager.h"
#include "Render.h"


int main(int argc, char** argv)
{
	//inicializar GLFW
	auto r = new Render(); //crear ventanas opengl
	auto obj = new Object3D("./data/Cube2.frs");


	r->setupObject(obj); //coppiar objeto a gpu
	r->objectList.push_back(obj); //añadir a lista de render
	r->mainLoop(); //dibujar!


	
	return 0;
}