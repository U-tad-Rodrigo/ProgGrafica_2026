#pragma once
#include "libMath.h"
#include "common.h"
#include "Shader.h"
#include "Material.h"
using namespace std;
using namespace libMath;

typedef struct {
    vec4float posicion;
    vec4float color;
    vec4float normal;
    vec4float texturaCoords;

}vertex_t;

class Object3D
{
public:
    static inline unsigned int idCounter;

    unsigned int objectId;

    vector<vertex_t> vertexList;
    vector<unsigned int> indexList;
    vec4float posicion = { 0,0,0,1 };
    vec4float rotacion = { 0,0,0,1 };
    vec4float escalado = { 2,2,2,1 };

    Shader* prg = nullptr;
    Material* mat = new Material();
    string frsModel = "";
    Object3D();
    Object3D(string frsModel);

    matrix4x4f computeModelMatrix();
    void moveObject(double timeStep);

    void computeNormals();

    void loadFromFile();
};

