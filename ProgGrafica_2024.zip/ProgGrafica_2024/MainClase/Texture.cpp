//
// Created by Rodrigo on 13/04/2026.
//
#include "Texture.h"

Texture::Texture(int w, int h, pixel_t color) {
    this->w = w;
    this->h = h;
    glGenTextures(1, &GLid);
    this->rawImage.resize(w*h);
    for (auto &p : rawImage) {
        p= color;
    }
    updateTexture();
}

Texture::Texture(string fileName) {
    this->fileName = fileName;
    // Por ahora crea una textura roja de 1x1 como placeholder
    // hasta que se implemente la carga de imagen
    this->w = 1;
    this->h = 1;
    glGenTextures(1, &GLid);
    rawImage.resize(1);
    rawImage[0] = {0xFF, 0, 0, 0xFF};
    updateTexture();
}

void Texture::updateTexture() {
    glBindTexture(GL_TEXTURE_2D, GLid);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rawImage.data());

}